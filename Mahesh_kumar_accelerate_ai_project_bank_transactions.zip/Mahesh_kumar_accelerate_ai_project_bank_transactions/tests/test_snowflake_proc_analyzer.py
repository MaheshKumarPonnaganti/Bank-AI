from snowflake_proc_analyzer import analyze_sql


def test_extracts_unique_child_procedures_and_tables():
    sql = """
    CREATE OR REPLACE PROCEDURE pr_xyz_fct_ld()
    RETURNS VARCHAR
    LANGUAGE SQL
    AS
    BEGIN
      CALL pr_log_process();
      CALL pr_dim_load();
      INSERT INTO abd SELECT * FROM asd;
      CALL pr_lu_load();
      DELETE FROM dfg;
      CALL pr_dim_load(); -- duplicate should be counted once
    END;
    """
    result = analyze_sql(sql, "pr_xyz_fct_ld")
    assert result.child_procedures == ["PR_LOG_PROCESS", "PR_DIM_LOAD", "PR_LU_LOAD"]
    assert result.tables == ["ABD", "ASD", "DFG"]
    assert result.child_procedure_count == 3
    assert result.table_count == 3


def test_handles_qualified_names_and_cte():
    result = analyze_sql(
        """
        WITH recent AS (SELECT * FROM raw.events)
        SELECT * FROM recent JOIN DB.SCHEMA.customers c ON 1 = 1;
        CALL DB.OPS.pr_child();
        """,
        "parent",
    )
    assert result.child_procedures == ["DB.OPS.PR_CHILD"]
    assert result.tables == ["RAW.EVENTS", "DB.SCHEMA.CUSTOMERS"]


def test_extracts_dependencies_from_javascript_sqltext():
    result = analyze_sql(
        """
        CREATE OR REPLACE PROCEDURE PR_X()
        RETURNS VARCHAR
        LANGUAGE JAVASCRIPT
        AS
        $$
        snowflake.execute({sqlText: `CALL DB.OPS.PR_LOG();`});
        snowflake.execute({sqlText: "INSERT INTO DB.APP.TARGET SELECT * FROM DB.APP.SOURCE"});
        snowflake.execute({sqlText: 'DELETE FROM DB.APP.OLD_ROWS'});
        $$
        """,
        "PR_X",
    )
    assert result.child_procedures == ["DB.OPS.PR_LOG"]
    assert result.tables == [
        "DB.APP.TARGET",
        "DB.APP.SOURCE",
        "DB.APP.OLD_ROWS",
    ]


def test_extracts_dependencies_from_language_sql_as_quoted_body():
    result = analyze_sql(
        """
        CREATE OR REPLACE PROCEDURE ADR_ODS.PR_INSERT_AXS_MRB_FCT(
          "PN_ITERATION_ID" NUMBER, "PN_MODEL_SUB_ID" NUMBER
        )
        RETURNS VARCHAR
        LANGUAGE SQL
        AS 'DECLARE
          lv_proc_name VARCHAR := ''PR_INSERT_AXS_MRB_FCT'';
        BEGIN
          CALL ADR_ODS.PR_ADR_COMMON_GET_ID_BY_CD_COMMON(
            ''ADR_ODS'', ''AXS_APPLICATION'', ''AXIS'');
          CALL "ADR_ODS".PR_ADR_COMMON_PROCESS_RUN_LOG(
            p_process_run_id => :pn_iteration_id);
          SELECT * INTO :lv_proc_name
          FROM adr_ods.adr_iteration_multi_display;
          INSERT INTO ADR_ODS.RESULT_TABLE
          SELECT * FROM ADR_STG.SOURCE_TABLE;
          DELETE FROM ADR_ODS.OLD_ROWS;
        END;'
        """,
        "ADR_ODS.PR_INSERT_AXS_MRB_FCT",
    )
    assert result.child_procedures == [
        "ADR_ODS.PR_ADR_COMMON_GET_ID_BY_CD_COMMON",
        "ADR_ODS.PR_ADR_COMMON_PROCESS_RUN_LOG",
    ]
    assert result.tables == [
        "ADR_ODS.ADR_ITERATION_MULTI_DISPLAY",
        "ADR_ODS.RESULT_TABLE",
        "ADR_STG.SOURCE_TABLE",
        "ADR_ODS.OLD_ROWS",
    ]
