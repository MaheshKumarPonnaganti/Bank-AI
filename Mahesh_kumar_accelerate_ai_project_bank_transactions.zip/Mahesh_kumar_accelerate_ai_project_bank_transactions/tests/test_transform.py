import pandas as pd

from bank_ai.query import build_report_csv, deterministic_query
from bank_ai.transform import build_gold, clean_silver, validate_bronze


def frames():
    return [pd.DataFrame({"Transaction Date": ["2024-01-02"], "Amount": ["$1,200.50"],
                          "Bank Name": ["acme"], "Region": ["north"]}) for _ in range(3)]


def test_validation_and_cleaning():
    assert validate_bronze(frames()) == []
    silver, summary = clean_silver(frames())
    assert len(silver) == 1
    assert silver.iloc[0].amount == 1200.50
    assert summary["duplicate_rows_removed"] == 2


def test_gold_and_local_question():
    silver, _ = clean_silver(frames())
    gold = build_gold(silver)
    result = deterministic_query("highest monthly transaction bank region", gold)
    assert "highest monthly" in result["answer"]
    assert not result["table"].empty
    assert "SELECT month, bank, region" in result["sql"]
    report = build_report_csv("highest monthly transaction bank region", result).decode()
    assert "question," in report
    assert "sql," in report
