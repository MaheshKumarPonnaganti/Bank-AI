from __future__ import annotations

import os
import sys
from pathlib import Path

import pandas as pd
import streamlit as st
from dotenv import load_dotenv

sys.path.insert(0, str(Path(__file__).parent / "src"))
from bank_ai.agents import AGENTS, architecture_prompt
from bank_ai.llm import LLMAdapter
from bank_ai.query import (
    build_report_csv,
    deterministic_query,
    prompt_for_question,
    validate_question,
)
from bank_ai.storage import persist_gold
from bank_ai.transform import build_gold, clean_silver, profile_data, validate_bronze

load_dotenv()
st.set_page_config(page_title="Transaction Intelligence", page_icon="🏦", layout="wide")
st.markdown("""<style>
.hero{padding:1.2rem 1.5rem;border-radius:14px;background:linear-gradient(110deg,#16213e,#0f766e);color:white}
.card{padding:1rem;border-radius:12px;background:#f4f7fb;border:1px solid #dbe4ee}
</style>""", unsafe_allow_html=True)
st.markdown('<div class="hero"><h1>🏦 Transaction Intelligence</h1><p>Anthropic-orchestrated medallion pipeline: Bronze → Silver → Gold</p></div>', unsafe_allow_html=True)
st.sidebar.header("Configuration")
chroma_path = st.sidebar.text_input("ChromaDB storage path", os.getenv("CHROMA_PATH", "chroma_data"))
api_key = st.sidebar.text_input(
    "Anthropic API key",
    value=os.getenv("ANTHROPIC_API_KEY", ""),
    type="password",
    help="Required to build the data architecture from your question.",
)
files = st.file_uploader("Upload exactly three bank-transaction CSV files", type="csv", accept_multiple_files=True)
if not files:
    st.info("Upload three CSVs to begin. Required fields: date, amount, bank, region.")
    st.stop()
if len(files) != 3:
    st.error(f"Please upload exactly three CSV files (currently {len(files)}).")
    st.stop()

upload_signature = tuple((file.name, file.size) for file in files)
if st.session_state.get("upload_signature") != upload_signature:
    st.session_state.upload_signature = upload_signature
    st.session_state.architecture = None
    st.session_state.architecture_question = ""
    st.session_state.bronze_ok = False
    st.session_state.silver_ok = False

frames = [pd.read_csv(file) for file in files]

st.header("Define the data question")
question = st.text_area(
    "What should the Gold layer answer?",
    value=st.session_state.get("architecture_question", ""),
    placeholder="Example: Which bank and region had the highest monthly transaction amount?",
    height=90,
)
if st.button("Build architecture with Anthropic", type="primary"):
    if not api_key:
        st.error("An Anthropic API key is required before the architecture can be built.")
        st.stop()
    question = validate_question(question)
    if not question:
        st.error("Enter a data question first.")
        st.stop()
    with st.spinner("Anthropic is designing the Bronze → Silver → Gold architecture..."):
        try:
            adapter = LLMAdapter(provider="anthropic", api_key=api_key)
            st.session_state.architecture = adapter.complete(architecture_prompt(question, frames))
            st.session_state.architecture_question = question
            st.session_state.architecture_approved = False
            st.session_state.bronze_ok = False
            st.session_state.silver_ok = False
        except RuntimeError as exc:
            st.error(f"Anthropic architecture request failed: {exc}")
            st.stop()

if not st.session_state.get("architecture"):
    st.info("Enter a question and build the architecture before starting the pipeline.")
    st.stop()

st.header("Agent-generated architecture")
st.markdown(st.session_state.architecture)
if st.button("Approve architecture and start Bronze", type="primary"):
    st.session_state.architecture_approved = True
if not st.session_state.get("architecture_approved"):
    st.stop()

st.header("🥉 Bronze layer")
for file, frame in zip(files, frames):
    with st.expander(f"{file.name} · {len(frame):,} rows"):
        st.dataframe(frame)
        st.json(profile_data(frame))
errors = validate_bronze(frames)
if errors:
    st.error("Validation issues: " + " | ".join(errors))
else:
    st.success("Bronze validation passed.")
st.info(AGENTS["Bronze"].explain({"files": 3, "rows": sum(len(f) for f in frames)}, errors))
if "bronze_ok" not in st.session_state:
    st.session_state.bronze_ok = False
if st.button("Proceed to next layer", key="bronze_next", disabled=bool(errors)):
    st.session_state.bronze_ok = True
if not st.session_state.bronze_ok:
    st.stop()

st.header("🥈 Silver layer")
silver, silver_summary = clean_silver(frames)
st.dataframe(silver)
st.json(silver_summary)
st.info(AGENTS["Silver"].explain(silver_summary))
if "silver_ok" not in st.session_state:
    st.session_state.silver_ok = False
if st.button("Proceed to next layer", key="silver_next"):
    st.session_state.silver_ok = True
if not st.session_state.silver_ok:
    st.stop()

st.header("🥇 Gold layer")
gold = build_gold(silver)
for name, frame in gold.items():
    st.subheader(name.replace("_", " ").title())
    st.dataframe(frame)
storage_message = persist_gold(gold, chroma_path)
st.success(storage_message)
st.info(AGENTS["Gold"].explain({name: len(frame) for name, frame in gold.items()}))

st.header("Ask the dashboard")
st.caption(f"Architecture question: {st.session_state.architecture_question}")
if st.button("Answer architecture question"):
    clean_question = st.session_state.architecture_question
    adapter = LLMAdapter(provider="anthropic", api_key=api_key)
    result = deterministic_query(clean_question, gold)
    if adapter.available:
        try:
            result["answer"] = adapter.complete(prompt_for_question(clean_question, gold))
            st.caption("Answered with Anthropic via LiteLLM.")
        except RuntimeError as exc:
            st.error(f"Anthropic answer request failed: {exc}")
            st.stop()
    else:
        st.error("Anthropic API key is required.")
        st.stop()
    st.success(result["answer"])
    st.download_button(
        "Download report",
        data=build_report_csv(clean_question, result),
        file_name="transaction_query_report.csv",
        mime="text/csv",
    )
    with st.expander("Show SQL query used to retrieve this data"):
        st.code(result["sql"], language="sql")
    st.dataframe(result["table"])
    if result["chart"] == "line" and not result["table"].empty:
        st.line_chart(result["table"].set_index("month")["total_amount"])
    elif not result["table"].empty and "total_amount" in result["table"]:
        st.bar_chart(result["table"].set_index(result["table"].columns[0])["total_amount"])
