# Bank Transaction Intelligence

An Anthropic-orchestrated Streamlit demo that processes **exactly three**
bank-transaction CSV uploads through a Bronze/Silver/Gold medallion pipeline.
The user asks a data question first; Anthropic designs the architecture around
that question, and deterministic pandas logic remains authoritative for data
quality and transformations.

## Run locally

```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
pip install -r requirements.txt
copy .env.example .env       # Windows (use cp on macOS/Linux)
streamlit run app.py
```

No LLM key or ChromaDB service is required. The UI explicitly shows when it uses
the safe deterministic question parser or CSV storage fallback. Set `CHROMA_PATH`
to configure persistent storage.

After submitting a dashboard question, use **Download report** to download a CSV
containing the question, answer, SQL retrieval statement, and returned rows.
Expand **Show SQL query used to retrieve this data** to inspect the generated
Gold-layer query. The LLM, when enabled, is used to narrate the result; the
deterministic Gold query remains the data retrieval source.

## CSV schema

Each file should contain `date`, `amount`, `bank`, and `region`. Common aliases
such as `Transaction Date`, `Bank Name`, `Amount`, `Location`, and `Transaction
ID` are recognized. Silver parses dates and currency strings, standardizes names,
removes duplicates, reports rejected records, and adds a `month` field.

Ready-to-upload examples are available in `sample_data/`: upload
`transactions_hyd.csv`, `transactions_bengaluru.csv`, and
`transactions_mumbai.csv` together. The examples intentionally use different
supported column aliases so the Bronze-to-Silver standardization can be tested.

## Anthropic architecture agent

Anthropic is required for this workflow. Set `ANTHROPIC_API_KEY` and
`ANTHROPIC_MODEL` in `.env` or
enter it in the sidebar. The app will not start the medallion pipeline or answer
the dashboard question without the key. LiteLLM sends two requests to
Anthropic: one to design the question-specific architecture and one to narrate
the approved Gold result. Data retrieval and cleaning remain deterministic.

The default model is `claude-haiku-4-5-20251001`. If your Anthropic account uses
another enabled model, set its exact model ID in `ANTHROPIC_MODEL` (or
`LLM_MODEL`).

The workflow is:

1. Upload the three source files and enter the business question.
2. Anthropic proposes Bronze ingestion, Silver cleaning, Gold metrics,
   retrieval, and validation steps using the uploaded schemas.
3. Approve the proposed architecture.
4. Review and approve Bronze, then review and approve Silver.
5. Inspect Gold and ask the approved architecture question.

## Tests

```bash
pytest -q
```

## Snowflake stored-procedure dependency analyzer

`snowflake_proc_analyzer.py` lists child procedures and referenced tables
without executing the procedure. It supports local SQL files:

```powershell
python snowflake_proc_analyzer.py --sql-file procedure.sql
python snowflake_proc_analyzer.py --sql-file procedure.sql --json
```

For Snowflake key-pair authentication, set the `SNOWFLAKE_*` variables from
`.env.example` (including the path to your private `.p8` key), then run:

```powershell
python snowflake_proc_analyzer.py --procedure DB.SCHEMA.PR_XYZ_FCT_LD
```

If the procedure is overloaded, include its argument signature in the
`--procedure` value, for example
`DB.SCHEMA.PR_XYZ_FCT_LD(VARCHAR, NUMBER)`. The analyzer uses `GET_DDL`, then
extracts unique `CALL`, `INSERT INTO`, `MERGE INTO`, `UPDATE`, `DELETE FROM`,
`FROM`, and `JOIN` references. Credentials are never printed or committed.
