from __future__ import annotations

import os


class LLMAdapter:
    def __init__(self, provider: str = "", model: str = "", api_key: str = "") -> None:
        self.provider = (provider or os.getenv("LLM_PROVIDER", "")).lower()
        self.model = model or os.getenv("LLM_MODEL", "")
        provider_keys = {
            "openai": "OPENAI_API_KEY", "azure": "AZURE_API_KEY",
            "anthropic": "ANTHROPIC_API_KEY", "gemini": "GEMINI_API_KEY",
        }
        self.api_key = api_key or os.getenv("LLM_API_KEY", "") or os.getenv(
            provider_keys.get(self.provider, ""), ""
        )

    @property
    def available(self) -> bool:
        return bool(self.provider and (self.api_key or self.provider == "ollama"))

    def complete(self, prompt: str) -> str:
        if not self.available:
            raise RuntimeError("No LLM credentials configured; using deterministic local query.")
        try:
            from litellm import completion
            from litellm import exceptions as litellm_exceptions
            model = self.model or os.getenv("ANTHROPIC_MODEL", "") or {
                                   "openai": "gpt-4o-mini", "azure": "azure/gpt-4o-mini",
                                   "anthropic": "anthropic/claude-haiku-4-5-20251001",
                                   "gemini": "gemini/gemini-1.5-flash",
                                   "ollama": "ollama/llama3.2"}.get(self.provider, self.provider)
            if self.provider == "anthropic" and "/" not in model:
                model = f"anthropic/{model}"
            kwargs = {"model": model, "messages": [{"role": "user", "content": prompt}]}
            if self.api_key:
                kwargs["api_key"] = self.api_key
            response = completion(**kwargs)
            return response.choices[0].message.content
        except ImportError as litellm_error:
            if self.provider != "anthropic":
                raise RuntimeError(
                    f"LiteLLM is required for provider '{self.provider}'. "
                    "Install dependencies with: pip install -r requirements.txt"
                ) from litellm_error
            try:
                from anthropic import Anthropic
            except ImportError as anthropic_error:
                raise RuntimeError(
                    "Neither LiteLLM nor the Anthropic SDK is installed. "
                    "Install dependencies with: pip install -r requirements.txt"
                ) from anthropic_error
            try:
                client = Anthropic(api_key=self.api_key)
                anthropic_model = (
                    self.model
                    or os.getenv("ANTHROPIC_MODEL", "")
                    or "claude-haiku-4-5-20251001"
                ).removeprefix("anthropic/")
                response = client.messages.create(
                    model=anthropic_model,
                    max_tokens=2048,
                    messages=[{"role": "user", "content": prompt}],
                )
                if not response.content or not getattr(response.content[0], "text", ""):
                    raise RuntimeError("Anthropic returned an empty response.")
                return response.content[0].text
            except (AttributeError, TypeError, ValueError) as exc:
                raise RuntimeError(f"Anthropic request unavailable: {exc}") from exc
        except (
            litellm_exceptions.APIError,
            litellm_exceptions.NotFoundError,
            litellm_exceptions.AuthenticationError,
            litellm_exceptions.BadRequestError,
            litellm_exceptions.RateLimitError,
            AttributeError,
            KeyError,
            TypeError,
            ValueError,
        ) as exc:
            raise RuntimeError(f"LLM request unavailable: {exc}") from exc
