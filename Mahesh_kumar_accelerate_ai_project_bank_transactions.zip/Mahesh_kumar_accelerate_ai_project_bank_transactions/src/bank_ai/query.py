from __future__ import annotations

import re
from io import StringIO
from typing import Any

import pandas as pd


def deterministic_query(question: str, gold: dict[str, pd.DataFrame]) -> dict[str, Any]:
    """Safe, intentionally small query grammar used when no LLM is configured."""
    q = question.lower()
    monthly = gold.get("monthly", pd.DataFrame()).copy()
    if monthly.empty:
        return {
            "answer": "There is no Gold data to query.",
            "table": monthly,
            "chart": "bar",
            "sql": "SELECT * FROM gold_monthly LIMIT 0;",
        }
    if any(word in q for word in ("highest", "top", "largest", "maximum")) and "month" in q:
        row = monthly.loc[monthly["total_amount"].idxmax()]
        answer = f"The highest monthly amount is {row.total_amount:,.2f} for {row.bank} in {row.region} during {row.month}."
        return {
            "answer": answer,
            "table": monthly.nlargest(10, "total_amount"),
            "chart": "bar",
            "sql": (
                "SELECT month, bank, region, transaction_count, total_amount\n"
                "FROM gold_monthly\n"
                "ORDER BY total_amount DESC\n"
                "LIMIT 10;"
            ),
        }
    if "count" in q or "number of" in q:
        table = monthly.groupby(["bank", "region"], as_index=False)["transaction_count"].sum()
        return {
            "answer": f"There are {int(table.transaction_count.sum()):,} transactions in total.",
            "table": table,
            "chart": "bar",
            "sql": (
                "SELECT bank, region, SUM(transaction_count) AS transaction_count\n"
                "FROM gold_monthly\n"
                "GROUP BY bank, region\n"
                "ORDER BY transaction_count DESC;"
            ),
        }
    if "trend" in q or "over time" in q:
        trends = gold["trends"]
        return {
            "answer": "Here is the transaction trend over time.",
            "table": trends,
            "chart": "line",
            "sql": (
                "SELECT month, transaction_count, total_amount\n"
                "FROM gold_trends\n"
                "ORDER BY month;"
            ),
        }
    table = gold["top_combinations"].head(10)
    return {
        "answer": "Showing the top bank-region combinations by total amount.",
        "table": table,
        "chart": "bar",
        "sql": (
            "SELECT bank, region, transaction_count, total_amount\n"
            "FROM gold_top_combinations\n"
            "ORDER BY total_amount DESC\n"
            "LIMIT 10;"
        ),
    }


def build_report_csv(question: str, result: dict[str, Any]) -> bytes:
    """Build a portable CSV report containing the answer, SQL, and result rows."""
    output = StringIO()
    output.write("section,value\n")
    for key in ("question", "answer", "sql"):
        value = str(question if key == "question" else result.get(key, ""))
        output.write(f"{key},{_csv_escape(value)}\n")
    output.write("\n")
    table = result.get("table", pd.DataFrame())
    if isinstance(table, pd.DataFrame) and not table.empty:
        table.to_csv(output, index=False)
    return output.getvalue().encode("utf-8")


def _csv_escape(value: str) -> str:
    return '"' + value.replace('"', '""').replace("\r", " ").replace("\n", "\\n") + '"'


def prompt_for_question(question: str, gold: dict[str, pd.DataFrame]) -> str:
    schema = {key: list(value.columns) for key, value in gold.items()}
    return (
        "Answer using only the supplied Gold tables. Never execute code or SQL. "
        f"Question: {question}\nSchema: {schema}\n"
        "Return concise natural language and identify the relevant table."
    )


def validate_question(question: str) -> str:
    return re.sub(r"[\x00-\x1f]", " ", question).strip()[:500]
