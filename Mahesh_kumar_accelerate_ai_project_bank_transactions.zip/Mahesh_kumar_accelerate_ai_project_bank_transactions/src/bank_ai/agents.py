from dataclasses import dataclass
from typing import Any

import pandas as pd


@dataclass
class StageAgent:
    stage: str
    prompt: str

    def explain(self, metadata: dict[str, Any], warnings: list[str] | None = None) -> str:
        warning_text = f" Warnings: {'; '.join(warnings)}" if warnings else ""
        return f"{self.stage} agent completed deterministic validation. {metadata}.{warning_text}"


AGENTS = {
    "Bronze": StageAgent("Bronze", "Profile uploaded transaction files and identify quality risks."),
    "Silver": StageAgent("Silver", "Explain standardized fields, coercions, and rejected records."),
    "Gold": StageAgent("Gold", "Explain business metrics and trends generated from validated data."),
}


def architecture_prompt(question: str, frames: list[pd.DataFrame]) -> str:
    """Create a constrained planning prompt for the Anthropic orchestrator."""
    schemas = [
        {"file_index": index, "columns": [str(column) for column in frame.columns],
         "rows": len(frame)}
        for index, frame in enumerate(frames, 1)
    ]
    return f"""
You are the architecture agent for a bank transaction analytics pipeline.
The user asked: {question}
The uploaded source files have these profiles: {schemas}

Design an executable medallion architecture specifically for this question:
1. Bronze: ingestion, profiling, schema mapping, and quality risks.
2. Silver: deterministic cleaning and standardization needed for the question.
3. Gold: exact aggregates, dimensions, metrics, and chart(s) needed to answer it.
4. Retrieval: state the Gold table(s) and SQL-style retrieval logic.
5. Validation: list checks and human approval points.

Return concise Markdown with headings Bronze, Silver, Gold, Retrieval, and
Validation. Do not invent source columns or claim to have executed anything.
The application will perform transformations deterministically after approval.
"""
