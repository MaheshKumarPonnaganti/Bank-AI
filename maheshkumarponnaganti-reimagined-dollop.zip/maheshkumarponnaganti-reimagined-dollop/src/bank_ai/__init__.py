"""Provider-agnostic bank transaction intelligence."""
