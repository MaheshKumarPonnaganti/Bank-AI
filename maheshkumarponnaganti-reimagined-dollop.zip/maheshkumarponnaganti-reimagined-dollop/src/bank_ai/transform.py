from __future__ import annotations

import re
from typing import Iterable

import pandas as pd


ALIASES = {
    "date": {"date", "transaction_date", "transactiondate", "timestamp", "trans_date"},
    "amount": {"amount", "transaction_amount", "value", "transaction_value", "amt"},
    "bank": {"bank", "bank_name", "institution", "financial_institution"},
    "region": {"region", "location", "area", "market", "state", "country"},
    "transaction_id": {"transaction_id", "transactionid", "id", "reference", "ref"},
}


def normalize_column(name: str) -> str:
    return re.sub(r"[^a-z0-9]+", "_", str(name).strip().lower()).strip("_")


def standardize_columns(df: pd.DataFrame) -> pd.DataFrame:
    result = df.copy()
    result.columns = [normalize_column(c) for c in result.columns]
    for canonical, candidates in ALIASES.items():
        if canonical not in result:
            match = next((c for c in result.columns if c in candidates), None)
            if match:
                result = result.rename(columns={match: canonical})
    return result


def profile_data(df: pd.DataFrame) -> dict:
    return {
        "rows": int(len(df)),
        "columns": int(len(df.columns)),
        "column_names": list(map(str, df.columns)),
        "missing_values": {str(k): int(v) for k, v in df.isna().sum().items() if v},
        "duplicate_rows": int(df.duplicated().sum()),
        "dtypes": {str(k): str(v) for k, v in df.dtypes.items()},
    }


def validate_bronze(frames: Iterable[pd.DataFrame]) -> list[str]:
    errors: list[str] = []
    for index, frame in enumerate(frames, 1):
        normalized = standardize_columns(frame)
        required = {"date", "amount", "bank", "region"}
        missing = sorted(required - set(normalized.columns))
        if missing:
            errors.append(f"File {index}: missing required columns: {', '.join(missing)}")
        if frame.empty:
            errors.append(f"File {index}: file is empty")
    return errors


def _clean_text(series: pd.Series) -> pd.Series:
    return series.fillna("Unknown").astype(str).str.strip().replace({"": "Unknown"})


def clean_silver(frames: Iterable[pd.DataFrame]) -> tuple[pd.DataFrame, dict]:
    parts: list[pd.DataFrame] = []
    missing_before: dict[str, int] = {}
    for frame in frames:
        item = standardize_columns(frame)
        for column, count in item.isna().sum().items():
            if count:
                missing_before[str(column)] = missing_before.get(str(column), 0) + int(count)
        for col in ("date", "amount", "bank", "region"):
            if col not in item:
                item[col] = pd.NA
        item["date"] = pd.to_datetime(item["date"], errors="coerce", utc=False)
        raw_amount = item["amount"].astype("string").str.replace(r"[$€£,\s]", "", regex=True)
        item["amount"] = pd.to_numeric(raw_amount, errors="coerce")
        item["bank"] = _clean_text(item["bank"]).str.title()
        item["region"] = _clean_text(item["region"]).str.title()
        parts.append(item)
    cleaned = pd.concat(parts, ignore_index=True) if parts else pd.DataFrame()
    before = len(cleaned)
    cleaned = cleaned.drop_duplicates().copy()
    invalid = int(cleaned[["date", "amount"]].isna().any(axis=1).sum()) if len(cleaned) else 0
    cleaned = cleaned.dropna(subset=["date", "amount"]).copy()
    cleaned["month"] = cleaned["date"].dt.to_period("M").astype(str)
    cleaned["amount"] = cleaned["amount"].round(2)
    summary = {
        "input_rows": before,
        "duplicate_rows_removed": before - len(cleaned) - invalid,
        "invalid_rows_removed": invalid,
        "output_rows": len(cleaned),
        "missing_values_before_cleaning": missing_before,
        "missing_values_after_cleaning": {
            str(k): int(v) for k, v in cleaned.isna().sum().items() if v
        },
    }
    return cleaned, summary


def build_gold(silver: pd.DataFrame) -> dict[str, pd.DataFrame]:
    if silver.empty:
        empty = pd.DataFrame(columns=["month", "bank", "region", "transaction_count", "total_amount"])
        return {"monthly": empty, "top_combinations": empty, "trends": pd.DataFrame()}
    monthly = (
        silver.groupby(["month", "bank", "region"], as_index=False)
        .agg(transaction_count=("amount", "size"), total_amount=("amount", "sum"))
        .sort_values(["month", "total_amount"], ascending=[True, False])
    )
    top = (
        monthly.groupby(["bank", "region"], as_index=False)
        .agg(transaction_count=("transaction_count", "sum"), total_amount=("total_amount", "sum"))
        .sort_values("total_amount", ascending=False)
    )
    trends = monthly.groupby("month", as_index=False).agg(
        transaction_count=("transaction_count", "sum"), total_amount=("total_amount", "sum")
    )
    return {"monthly": monthly, "top_combinations": top, "trends": trends}
