from dataclasses import dataclass
from typing import Any


@dataclass
class StageAgent:
    stage: str
    prompt: str

    def explain(self, metadata: dict[str, Any], warnings: list[str] | None = None) -> str:
        warning_text = f" Warnings: {'; '.join(warnings)}" if warnings else ""
        return f"{self.stage} agent completed deterministic validation. {metadata}.{warning_text}"


AGENTS = {
    "Bronze": StageAgent("Bronze", "Profile uploaded transaction files and identify quality risks."),
    "Silver": StageAgent("Silver", "Explain standardized fields, coercions, and rejected records."),
    "Gold": StageAgent("Gold", "Explain business metrics and trends generated from validated data."),
}
