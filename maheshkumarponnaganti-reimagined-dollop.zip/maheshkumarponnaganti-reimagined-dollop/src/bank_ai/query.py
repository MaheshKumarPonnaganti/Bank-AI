from __future__ import annotations

import re
from dataclasses import dataclass
from io import StringIO
from typing import Any

import pandas as pd


@dataclass(frozen=True)
class QueryIntent:
    metric: str = "amount"
    dimension: str | None = None
    ranking: str | None = None
    limit: int | None = None
    trend: bool = False
    bank: str | None = None
    region: str | None = None

    @property
    def ranking_label(self) -> str:
        return "highest" if self.ranking == "desc" else "lowest"


_METRIC_NAMES = {
    "average": ("average", "avg", "mean"),
    "count": ("count", "number of", "how many", "transactions"),
    "amount": ("amount", "total", "value", "spend", "volume"),
}


def parse_intent(question: str, gold: dict[str, pd.DataFrame]) -> QueryIntent:
    """Parse a small, allow-listed language grammar without evaluating user input."""
    q = validate_question(question).lower()
    if any(term in q for term in _METRIC_NAMES["average"]):
        metric = "average"
    elif any(term in q for term in _METRIC_NAMES["amount"]):
        metric = "amount"
    elif any(term in q for term in _METRIC_NAMES["count"]):
        metric = "count"
    else:
        metric = "amount"
    dimension = None
    has_month = bool(re.search(r"\b(month|monthly|months|over time)\b", q))
    has_bank = bool(re.search(r"\b(bank|banks|institution)\b", q))
    has_region = bool(re.search(r"\b(region|regions|location|area|market)\b", q))
    has_ranking = bool(re.search(r"\b(lowest|bottom|smallest|minimum|min|highest|top|largest|maximum|max)\b", q))
    if has_month and has_bank and has_region and has_ranking:
        dimension = "month_bank_region"
    elif has_month:
        dimension = "month"
    elif re.search(r"\bby\s+(?:the\s+)?(?:bank|banks|institution)\b", q):
        dimension = "bank"
    elif re.search(r"\bby\s+(?:the\s+)?(?:region|regions|location|area|market)\b", q):
        dimension = "region"
    elif has_bank and has_region:
        dimension = "bank_region"
    elif re.search(r"\b(bank|banks|institution)\b", q):
        dimension = "bank"
    elif re.search(r"\b(region|regions|location|area|market)\b", q):
        dimension = "region"

    ranking = None
    if re.search(r"\b(lowest|bottom|smallest|minimum|min)\b", q):
        ranking = "asc"
    elif re.search(r"\b(highest|top|largest|maximum|max)\b", q):
        ranking = "desc"

    limit_match = re.search(r"\b(?:top|bottom)\s+(\d+)\b", q)
    limit = min(int(limit_match.group(1)), 100) if limit_match else None
    if ranking and limit is None:
        limit = 10

    monthly = gold.get("monthly", pd.DataFrame())
    return QueryIntent(
        metric=metric,
        dimension=dimension,
        ranking=ranking,
        limit=limit,
        trend=bool(re.search(r"\b(trend|trends|over time|trajectory)\b", q)),
        bank=_find_value(q, monthly.get("bank", pd.Series(dtype=str))),
        region=_find_value(q, monthly.get("region", pd.Series(dtype=str))),
    )


def deterministic_query(question: str, gold: dict[str, pd.DataFrame]) -> dict[str, Any]:
    """Answer from Gold data using only allow-listed pandas operations."""
    clean_question = validate_question(question)
    monthly = gold.get("monthly", pd.DataFrame()).copy()
    if monthly.empty:
        return _result(
            "There is no Gold data to query.",
            monthly,
            "bar",
            "SELECT * FROM gold_monthly LIMIT 0;",
            intent=QueryIntent(),
        )

    intent = parse_intent(clean_question, gold)
    filtered = monthly
    if intent.bank:
        filtered = filtered[filtered["bank"].eq(intent.bank)]
    if intent.region:
        filtered = filtered[filtered["region"].eq(intent.region)]
    if filtered.empty:
        filters = _filter_description(intent)
        return _result(f"No Gold records matched {filters}.", filtered, "bar", _sql(intent), intent)

    if intent.trend:
        table = _aggregate(filtered, "month", intent.metric)
        table = table.sort_values("month")
        answer = f"Here is the {intent.metric} trend over time"
        chart = "line"
    else:
        table = _aggregate(filtered, intent.dimension, intent.metric)
        metric_column = _metric_column(intent.metric)
        group_columns = (
            ["month", "bank", "region"]
            if intent.dimension == "month_bank_region"
            else ["bank", "region"]
            if intent.dimension == "bank_region"
            else (
            [intent.dimension] if intent.dimension else []
            )
        )
        value_columns = [metric_column]
        if intent.metric == "average":
            value_columns.append("transaction_count")
        table = table[group_columns + value_columns]
        sort_column = _metric_column(intent.metric)
        if intent.ranking:
            table = table.sort_values(sort_column, ascending=intent.ranking == "asc")
            if intent.limit:
                table = table.head(intent.limit)
        answer = _describe_result(table, intent)
        chart = "bar"

    return _result(f"{answer}.", table, chart, _sql(intent), intent)


def _aggregate(frame: pd.DataFrame, dimension: str | None, metric: str) -> pd.DataFrame:
    if dimension is None:
        grouped = pd.DataFrame(
            {
                "transaction_count": [int(frame["transaction_count"].sum())],
                "total_amount": [float(frame["total_amount"].sum())],
            }
        )
    else:
        group_columns = (
            ["month", "bank", "region"]
            if dimension == "month_bank_region"
            else ["bank", "region"]
            if dimension == "bank_region"
            else [dimension]
        )
        grouped = (
            frame.groupby(group_columns, as_index=False)[["transaction_count", "total_amount"]]
            .sum()
            .sort_values(group_columns)
        )
    if metric == "average":
        grouped["average_amount"] = (
            grouped["total_amount"] / grouped["transaction_count"].replace(0, pd.NA)
        ).round(2)
    return grouped.reset_index(drop=True)


def _describe_result(table: pd.DataFrame, intent: QueryIntent) -> str:
    metric_column = _metric_column(intent.metric)
    label = {"amount": "amount", "count": "transaction count", "average": "average amount"}[
        intent.metric
    ]
    if intent.ranking and not table.empty and intent.dimension:
        row = table.iloc[0]
        if intent.dimension in {"bank_region", "month_bank_region"}:
            group = f"{row['bank']} in {row['region']}"
            if intent.dimension == "month_bank_region":
                group = f"{group} during {row['month']}"
        else:
            group = str(row[intent.dimension])
        dimension_label = (
            "monthly "
            if intent.dimension in {"month", "month_bank_region"}
            else ""
        )
        return f"The {intent.ranking_label} {dimension_label}{label} is {row[metric_column]:,.2f} for {group}"
    if intent.dimension:
        return f"Here is the {label} by {intent.dimension}"
    return f"The total {label} is {table.iloc[0][metric_column]:,.2f}"


def _metric_column(metric: str) -> str:
    return {"amount": "total_amount", "count": "transaction_count", "average": "average_amount"}[
        metric
    ]


def _sql(intent: QueryIntent) -> str:
    column = _metric_column(intent.metric)
    dimension = intent.dimension
    order = " ASC" if intent.ranking == "asc" else " DESC"
    limit = f"\nLIMIT {intent.limit};" if intent.limit else ";"
    if dimension is None:
        return (
            f"-- Deterministic Gold retrieval: total {intent.metric}\n"
            f"SELECT SUM({column}) AS {column} FROM gold_monthly;"
        )
    if dimension == "month_bank_region" and intent.ranking:
        return (
            "SELECT month, bank, region, transaction_count, total_amount\n"
            f"FROM gold_monthly\nORDER BY total_amount{order}"
            f"{limit}"
        )
    select_columns = (
        "month, bank, region"
        if dimension == "month_bank_region"
        else "bank, region"
        if dimension == "bank_region"
        else dimension
    )
    return (
        f"-- Deterministic Gold retrieval: {intent.metric} by {dimension}\n"
        f"SELECT {select_columns}, {column} FROM gold_monthly\n"
        f"GROUP BY {select_columns}\nORDER BY {column}{order}{limit}"
    )


def _result(
    answer: str,
    table: pd.DataFrame,
    chart: str,
    sql: str,
    intent: QueryIntent,
) -> dict[str, Any]:
    metric_labels = {
        "amount": "Total amount",
        "count": "Transaction count",
        "average": "Average amount",
    }
    dimensions = {
        None: "all data",
        "bank": "bank",
        "region": "region",
        "month": "month",
        "bank_region": "bank and region",
        "month_bank_region": "month, bank, and region",
    }
    filters = [f"Bank: {intent.bank}" for _ in [0] if intent.bank]
    filters += [f"Region: {intent.region}" for _ in [0] if intent.region]
    return {
        "answer": answer,
        "table": table,
        "chart": chart,
        "sql": sql,
        "intent": intent,
        "metric_column": _metric_column(intent.metric),
        "metric_label": metric_labels[intent.metric],
        "dimension_label": dimensions[intent.dimension],
        "dashboard_title": (
            f"{metric_labels[intent.metric]} by {dimensions[intent.dimension]}"
            if intent.dimension
            else metric_labels[intent.metric]
        ),
        "filters": filters,
    }


def _find_value(question: str, values: pd.Series) -> str | None:
    for value in sorted((str(v) for v in values.dropna().unique()), key=len, reverse=True):
        if re.search(rf"(?<!\w){re.escape(value.lower())}(?!\w)", question):
            return value
    return None


def _filter_description(intent: QueryIntent) -> str:
    parts = [f"bank {intent.bank}" for _ in [0] if intent.bank]
    parts += [f"region {intent.region}" for _ in [0] if intent.region]
    return " and ".join(parts) or "the supplied filters"


def build_report_csv(question: str, result: dict[str, Any]) -> bytes:
    """Build a portable CSV report containing the answer, SQL, and result rows."""
    output = StringIO()
    output.write("section,value\n")
    for key in ("question", "answer", "sql"):
        value = str(question if key == "question" else result.get(key, ""))
        output.write(f"{key},{_csv_escape(value)}\n")
    output.write("\n")
    table = result.get("table", pd.DataFrame())
    if isinstance(table, pd.DataFrame) and not table.empty:
        table.to_csv(output, index=False)
    return output.getvalue().encode("utf-8")


def _csv_escape(value: str) -> str:
    return '"' + value.replace('"', '""').replace("\r", " ").replace("\n", "\\n") + '"'


def prompt_for_question(question: str, gold: dict[str, pd.DataFrame]) -> str:
    schema = {key: list(value.columns) for key, value in gold.items()}
    return (
        "Answer using only the supplied Gold tables. Never execute code or SQL. "
        f"Question: {question}\nSchema: {schema}\n"
        "Return concise natural language and identify the relevant table."
    )


def validate_question(question: str) -> str:
    return re.sub(r"[\x00-\x1f]", " ", question).strip()[:500]
