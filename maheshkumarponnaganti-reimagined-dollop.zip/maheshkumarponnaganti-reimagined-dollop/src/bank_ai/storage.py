from __future__ import annotations

import json
from pathlib import Path

import pandas as pd


def persist_gold(gold: dict[str, pd.DataFrame], path: str) -> str:
    target = Path(path)
    target.mkdir(parents=True, exist_ok=True)
    try:
        import chromadb
        client = chromadb.PersistentClient(path=str(target))
        collection = client.get_or_create_collection("bank_gold")
        docs = []
        ids = []
        for name, frame in gold.items():
            for i, row in frame.iterrows():
                ids.append(f"{name}-{i}")
                docs.append(json.dumps({"table": name, **row.to_dict()}, default=str))
        if docs:
            collection.upsert(ids=ids, documents=docs)
        return f"Persisted {len(docs)} Gold records to ChromaDB ({target})."
    except ImportError:
        for name, frame in gold.items():
            frame.to_csv(target / f"{name}.csv", index=False)
        return f"ChromaDB is unavailable; persisted Gold CSV fallback to {target}."
    except (OSError, RuntimeError, ValueError) as exc:
        for name, frame in gold.items():
            frame.to_csv(target / f"{name}.csv", index=False)
        return f"ChromaDB could not initialize ({exc}); persisted Gold CSV fallback to {target}."
