from __future__ import annotations

import os


class LLMAdapter:
    def __init__(self, provider: str = "", model: str = "", api_key: str = "") -> None:
        self.provider = (provider or os.getenv("LLM_PROVIDER", "")).lower()
        self.model = model or os.getenv("LLM_MODEL", "")
        provider_keys = {
            "openai": "OPENAI_API_KEY", "azure": "AZURE_API_KEY",
            "anthropic": "ANTHROPIC_API_KEY", "gemini": "GEMINI_API_KEY",
        }
        self.api_key = api_key or os.getenv("LLM_API_KEY", "") or os.getenv(
            provider_keys.get(self.provider, ""), ""
        )

    @property
    def available(self) -> bool:
        return bool(self.provider and (self.api_key or self.provider == "ollama"))

    def complete(self, prompt: str) -> str:
        if not self.available:
            raise RuntimeError("No LLM credentials configured; using deterministic local query.")
        try:
            from litellm import completion, exceptions as litellm_exceptions

            model = self.model or {"openai": "gpt-4o-mini", "azure": "azure/gpt-4o-mini",
                                   "anthropic": "anthropic/claude-haiku-4-5-20251001",
                                   "gemini": "gemini/gemini-1.5-flash",
                                   "ollama": "ollama/llama3.2"}.get(self.provider, self.provider)
            if self.provider == "anthropic" and "/" not in model:
                model = f"anthropic/{model}"
            if model in {
                "claude-3-5-haiku-latest",
                "anthropic/claude-3-5-haiku-latest",
            }:
                model = "anthropic/claude-haiku-4-5-20251001"
            kwargs = {"model": model, "messages": [{"role": "user", "content": prompt}]}
            if self.api_key:
                kwargs["api_key"] = self.api_key
            response = completion(**kwargs)
            return response.choices[0].message.content
        except litellm_exceptions.APIError as exc:
            raise RuntimeError(f"Anthropic/LLM request unavailable: {exc}") from exc
        except (ImportError, AttributeError, KeyError, TypeError, ValueError) as exc:
            raise RuntimeError(f"LLM request unavailable: {exc}") from exc
