# Bank Transaction Intelligence

A provider-agnostic Streamlit demo that processes **exactly three** bank-transaction
CSV uploads through a Bronze/Silver/Gold medallion pipeline. Deterministic pandas
logic is authoritative; lightweight stage agents provide explainable summaries.

## Run locally

```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
pip install -r requirements.txt
copy .env.example .env       # Windows (use cp on macOS/Linux)
streamlit run app.py
```

The UI collects the three data files first, then requires an Anthropic API key
to validate the business question. It requires human approval before Bronze
validation, Silver transformation, and Gold aggregation. Set `CHROMA_PATH` to
configure persistent storage. Add `ANTHROPIC_API_KEY` in `.env` or enter it in
the sidebar. Anthropic classifies the request but never performs retrieval and
never replaces the deterministic Gold result.

After submitting a dashboard question, use **Download report** to download a CSV
containing the question, answer, SQL retrieval statement, and returned rows.
Expand **Show SQL query used to retrieve this data** to inspect the generated
Gold-layer query. Questions support amount, count, and average metrics; month,
bank, and region dimensions; highest/top/lowest rankings; trends; and bank or
region filters. Retrieval is always performed by the allow-listed deterministic
parser against Gold data. User-entered SQL, Python, and code are never executed.

## CSV schema

Each file should contain `date`, `amount`, `bank`, and `region`. Common aliases
such as `Transaction Date`, `Bank Name`, `Amount`, `Location`, and `Transaction
ID` are recognized. Silver parses dates and currency strings, standardizes names,
removes duplicates, reports rejected records, and adds a `month` field.

Ready-to-upload examples are available in `sample_data/`: upload
`transactions_hyd.csv`, `transactions_bengaluru.csv`, and
`transactions_mumbai.csv` together. The examples intentionally use different
supported column aliases so the Bronze-to-Silver standardization can be tested.

## Tests

```bash
pytest -q
```
