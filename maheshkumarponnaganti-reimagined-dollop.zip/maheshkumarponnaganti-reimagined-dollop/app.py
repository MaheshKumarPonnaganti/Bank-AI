from __future__ import annotations

import os
import sys
from pathlib import Path

import pandas as pd
import streamlit as st
from dotenv import load_dotenv

sys.path.insert(0, str(Path(__file__).parent / "src"))
from bank_ai.agents import AGENTS
from bank_ai.llm import LLMAdapter
from bank_ai.query import build_report_csv, deterministic_query, validate_question
from bank_ai.storage import persist_gold
from bank_ai.transform import build_gold, clean_silver, profile_data, validate_bronze


load_dotenv()
st.set_page_config(page_title="Transaction Intelligence", page_icon="🏦", layout="wide")
st.markdown(
    """<style>
    .hero{padding:1.2rem 1.5rem;border-radius:14px;background:linear-gradient(110deg,#16213e,#0f766e);color:white}
    </style>""",
    unsafe_allow_html=True,
)
st.markdown(
    '<div class="hero"><h1>🏦 Transaction Intelligence</h1>'
    "<p>Anthropic-validated Bronze → Silver → Gold medallion pipeline</p></div>",
    unsafe_allow_html=True,
)

st.sidebar.header("Configuration")
chroma_path = st.sidebar.text_input("ChromaDB storage path", os.getenv("CHROMA_PATH", "chroma_data"))
anthropic_key = st.sidebar.text_input(
    "Anthropic API key (required)",
    value=os.getenv("ANTHROPIC_API_KEY", ""),
    type="password",
)

st.header("1. Collect transaction data")
files = st.file_uploader(
    "Upload exactly three bank-transaction CSV files",
    type="csv",
    accept_multiple_files=True,
)
if not files:
    st.info("Upload three CSVs to begin. Required fields: date, amount, bank, region.")
    st.stop()
if len(files) != 3:
    st.error(f"Please upload exactly three CSV files (currently {len(files)}).")
    st.stop()

upload_signature = tuple((file.name, file.size) for file in files)
if st.session_state.get("upload_signature") != upload_signature:
    st.session_state.upload_signature = upload_signature
    for key in (
        "bronze_approved",
        "silver_approved",
        "gold_approved",
        "silver",
        "gold",
        "dashboard_result",
        "anthropic_summary",
        "question",
    ):
        st.session_state.pop(key, None)

frames = [pd.read_csv(file) for file in files]

st.header("2. Ask the question")
st.caption(
    "After data collection, ask what you want to know. Anthropic must validate "
    "the request before the medallion layers can run."
)
with st.form("question_form"):
    question = st.text_input(
        "What do you want to know?",
        value=st.session_state.get("question", ""),
        placeholder="Example: Show the top 5 banks by average amount in the North region",
    )
    question_submitted = st.form_submit_button("Validate question with Anthropic")

if question_submitted:
    clean_question = validate_question(question)
    if not clean_question:
        st.error("Enter a question before starting the pipeline.")
        st.stop()
    if not anthropic_key:
        st.error("An Anthropic API key is required before the question can be validated.")
        st.stop()
    adapter = LLMAdapter("anthropic", api_key=anthropic_key)
    try:
        st.session_state.anthropic_summary = adapter.complete(
            "Classify this dashboard request in one concise sentence. "
            "Do not write SQL, Python, or code; do not invent data. "
            f"Request: {clean_question}"
        )
    except RuntimeError as exc:
        st.error(f"Anthropic validation failed. No medallion layer was started: {exc}")
        st.stop()
    if clean_question != st.session_state.get("question"):
        for key in ("bronze_approved", "silver_approved", "gold_approved", "silver", "gold", "dashboard_result"):
            st.session_state.pop(key, None)
    st.session_state.question = clean_question

if not st.session_state.get("question"):
    st.info("Ask a question after uploading the data. The layers will not run until Anthropic validates it.")
    st.stop()

if not anthropic_key:
    st.error("An Anthropic API key is required to continue.")
    st.stop()

active_question = st.session_state.question
st.success(f"Anthropic-validated question: {active_question}")
if st.session_state.get("anthropic_summary"):
    st.caption("Anthropic request analysis")
    st.write(st.session_state.anthropic_summary)

st.header("3. Bronze layer — human approval required")
st.write("Review the uploaded files before Bronze validation and normalization.")
bronze_preview = pd.DataFrame(
    {"file": [file.name for file in files], "rows": [len(frame) for frame in frames]}
)
st.dataframe(bronze_preview, hide_index=True)
if st.button("Approve and run Bronze validation", key="bronze_approval"):
    st.session_state.bronze_approved = True
if not st.session_state.get("bronze_approved"):
    st.stop()

errors = validate_bronze(frames)
for file, frame in zip(files, frames):
    with st.expander(f"{file.name} · {len(frame):,} rows"):
        st.dataframe(frame)
        st.json(profile_data(frame))
if errors:
    st.error("Validation issues: " + " | ".join(errors))
    st.stop()
st.success("Bronze validation passed.")
st.info(AGENTS["Bronze"].explain({"files": 3, "rows": sum(len(f) for f in frames)}))

st.header("4. Silver layer — human approval required")
st.write("Approve cleaning, type coercion, deduplication, and rejected-record handling.")
if st.button("Approve and run Silver transformations", key="silver_approval"):
    st.session_state.silver_approved = True
if not st.session_state.get("silver_approved"):
    st.stop()

silver, silver_summary = clean_silver(frames)
st.session_state.silver = silver
st.dataframe(silver)
st.json(silver_summary)
st.info(AGENTS["Silver"].explain(silver_summary))

st.header("5. Gold layer — human approval required")
st.write("Approve aggregation into the Gold tables used to answer the active question.")
if st.button("Approve and build Gold dashboard", key="gold_approval"):
    st.session_state.gold_approved = True
if not st.session_state.get("gold_approved"):
    st.stop()

gold = build_gold(silver)
st.session_state.gold = gold
for name, frame in gold.items():
    st.subheader(name.replace("_", " ").title())
    st.dataframe(frame)
st.success(persist_gold(gold, chroma_path))
st.info(AGENTS["Gold"].explain({name: len(frame) for name, frame in gold.items()}))

result = deterministic_query(active_question, gold)
st.session_state.dashboard_result = (active_question, result)
st.header("6. Dashboard for the user question")
st.caption(f"Question: {active_question}")
if result["filters"]:
    st.caption(" · ".join(result["filters"]))
st.success(result["answer"])
table = result["table"]
if not table.empty:
    metric_column = result["metric_column"]
    if result["intent"].metric == "average" and "transaction_count" in table:
        total_count = table["transaction_count"].sum()
        total_value = (
            (table[metric_column] * table["transaction_count"]).sum() / total_count
            if total_count
            else 0
        )
    else:
        total_value = table[metric_column].sum()
    st.metric(result["metric_label"], f"{total_value:,.2f}")
st.download_button(
    "Download report",
    data=build_report_csv(active_question, result),
    file_name="transaction_query_report.csv",
    mime="text/csv",
)
with st.expander("Show deterministic Gold retrieval"):
    st.code(result["sql"], language="sql")
st.markdown(f"**{result['dashboard_title']}**")
st.dataframe(table, hide_index=True)
if not table.empty:
    if result["chart"] == "line" and "month" in table:
        st.line_chart(table.set_index("month")[result["metric_column"]])
    elif result["chart"] == "bar" and result["intent"].dimension:
        chart_table = table.copy()
        if result["intent"].dimension in {"bank_region", "month_bank_region"}:
            chart_table["group"] = (
                chart_table["bank"].astype(str) + " · " + chart_table["region"].astype(str)
            )
            if result["intent"].dimension == "month_bank_region":
                chart_table["group"] += " · " + chart_table["month"].astype(str)
            chart_dimension = "group"
        else:
            chart_dimension = result["intent"].dimension
        st.bar_chart(chart_table.set_index(chart_dimension)[result["metric_column"]])
