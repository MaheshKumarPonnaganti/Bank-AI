import pandas as pd

from bank_ai.query import build_report_csv, deterministic_query, parse_intent
from bank_ai.transform import build_gold, clean_silver, validate_bronze


def frames():
    return [pd.DataFrame({"Transaction Date": ["2024-01-02"], "Amount": ["$1,200.50"],
                          "Bank Name": ["acme"], "Region": ["north"]}) for _ in range(3)]


def test_validation_and_cleaning():
    assert validate_bronze(frames()) == []
    silver, summary = clean_silver(frames())
    assert len(silver) == 1
    assert silver.iloc[0].amount == 1200.50
    assert summary["duplicate_rows_removed"] == 2


def test_gold_and_local_question():
    silver, _ = clean_silver(frames())
    gold = build_gold(silver)
    result = deterministic_query("highest monthly transaction bank region", gold)
    assert "highest monthly" in result["answer"]
    assert not result["table"].empty
    assert "SELECT month, bank, region" in result["sql"]
    report = build_report_csv("highest monthly transaction bank region", result).decode()
    assert "question," in report
    assert "sql," in report


def test_query_intent_supports_metrics_dimensions_rankings_and_filters():
    silver = pd.DataFrame(
        {
            "date": pd.to_datetime(["2024-01-02", "2024-02-02", "2024-02-03"]),
            "amount": [100.0, 300.0, 100.0],
            "bank": ["Acme", "Acme", "Zenith"],
            "region": ["North", "North", "South"],
        }
    )
    silver["month"] = silver["date"].dt.to_period("M").astype(str)
    gold = build_gold(silver)

    intent = parse_intent("show the lowest average amount by bank in the north region", gold)
    assert intent.metric == "average"
    assert intent.dimension == "bank"
    assert intent.ranking == "asc"
    assert intent.region == "North"

    result = deterministic_query("show the lowest average amount by bank in the north region", gold)
    assert result["table"].iloc[0]["bank"] == "Acme"
    assert "average_amount" in result["table"]
    assert result["dashboard_title"] == "Average amount by bank"
    assert result["filters"] == ["Region: North"]


def test_query_trend_and_count_are_retrieved_from_gold():
    silver, _ = clean_silver(frames())
    gold = build_gold(silver)

    trend = deterministic_query("show the transaction count trend over time", gold)
    assert trend["chart"] == "line"
    assert list(trend["table"].columns) == ["month", "transaction_count", "total_amount"]

    count = deterministic_query("how many transactions by bank?", gold)
    assert "transaction_count" in count["table"]
    assert "total_amount" not in count["table"]
    assert count["dashboard_title"] == "Transaction count by bank"
